function sumAb(a, b) {
    return a + b;
}
var tong = sumAb(3, 6);
console.log('tong của 2 sô là:' + tong);

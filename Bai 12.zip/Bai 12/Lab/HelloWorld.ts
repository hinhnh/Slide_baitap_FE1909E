class Customer {
    Name: string;
    constructor(firstName: string, lastName: string) {
        this.Name = firstName + "  " + lastName;
    }
    GetName() {
        return "Hello, " + this.Name;
    }
}
let cust = new Customer("Jimi", "Scott");

function hello(person) {
    return "Hello, " + person;
}

let user = "Aamod Tiwari";
const result = hello(user);
console.log("Result", result)
console.log(cust);

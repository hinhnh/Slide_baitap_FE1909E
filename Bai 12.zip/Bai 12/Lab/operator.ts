class Arithmetic  
{  
 operator(a: number, b: number)  
 {  
  let add: number, sub: number, mul: number, div: number, mod: number, incre: number, dec: number;  
  add = a + b;  
  sub = a - b;  
  mul = a * b;  
  div = a / b;  
  mod = a % b;  
  incre = ++a;  
  dec = --b;  
  var span = document.createElement("span");  
  span.innerText = "\n Addition Of Number is: " + add + 
                   "\n" + "Subtraction Of Number is: "+sub +
                   "\n "+"Multiplication Of Number is -> "+mul+
                   "\n "+ "Division Of Number is: "+div+
                    "\n "+"Modulus Of Number is: "+mod+
                    "\n "+" Increment Of First Number is -> "+incre+
                    "\n "+"  Decrement Of Second Number is -> "+dec;  
  document.body.appendChild(span);  
 }  
}  

window.onload = () =>  
 {  
  var a: number, b: number;  
  a = parseInt(prompt("Enter A First Number"));  
  b = parseInt(prompt("Enter A Second Number"));  
  var greeter = new Arithmetic();  
  var span = document.createElement("span");  
  span.style.color = "green";  
  span.innerText = "First number is->" + a + "\n" + "Second Number is->" + b + "\n";  
  document.body.appendChild(span);  
  greeter.operator(a, b);  
 };  
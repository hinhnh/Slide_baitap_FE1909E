import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navigate-url',
  templateUrl: './navigate-url.component.html',
  styleUrls: ['./navigate-url.component.css']
})
export class NavigateUrlComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

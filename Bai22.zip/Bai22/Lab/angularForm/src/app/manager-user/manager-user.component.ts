import { Component, OnInit } from '@angular/core';
import {UserService} from './user.service';
import { from } from 'rxjs';
@Component({
  selector: 'app-manager-user',
  templateUrl: './manager-user.component.html',
  styleUrls: ['./manager-user.component.css']
})
export class ManagerUserComponent implements OnInit {
   listUsers: any[];
  constructor(private userService: UserService) {  }

  ngOnInit() {
    /*         
    // Create an Observable out of a promise
const data = from(fetch('./assets/api/users.json'));
// Subscribe to begin listening for async result
data.subscribe({
  next(response) { console.log(response); },
  error(err) { console.error('Error: ' + err); },
  complete() { console.log('Completed'); }
});

*/  
     // Dung http với Observable
     this.userService.getJSON().subscribe(
       (res: any) => {
            this.listUsers = res;
            console.log(this.listUsers);
          }, 
      err => {
          console.log(err);
            }
      );


    /*
    // Dung http với Promise
    this.userService.getUsers()
      .then( result => {
        console.log('ALL Data: ', result);
        this.listUsers = result;
      })
      .catch( error => {
        console.log('Error Getting Data: ', error);
      });
     */
   
  }

}
//https://www.metaltoad.com/blog/angular-5-making-api-calls-httpclient-service//
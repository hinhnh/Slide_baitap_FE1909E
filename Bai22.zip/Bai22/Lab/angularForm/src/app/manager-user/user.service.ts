
//https://www.djamware.com/post/5da31946ae418d042e1aef1d/angular-8-tutorial-observable-and-rxjs-examples
//https://www.techiediaries.com/angular-local-json-files/
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  results: any[];
  constructor( private http: HttpClient) {

   }


  getUsers(): Promise<any[]>{
    return this.http.get<any>("http://jsonplaceholder.typicode.com/users").toPromise();

  }

  getJsonData(): Promise<any[]>{
    return this.http.get<any[]>('http://localhost:4200/assets/api/users.json').toPromise();
  }

  public getJSON(): Observable<any> {
    return this.http.get("assets/api/users.json");
}

 getAllUsers(): Observable<any> {
  return this.http.get<any>("http://jsonplaceholder.typicode.com/users");
  }
  
  

}

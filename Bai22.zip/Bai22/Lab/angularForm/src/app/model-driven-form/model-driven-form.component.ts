import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-model-driven-form',
  templateUrl: './model-driven-form.component.html',
  styleUrls: ['./model-driven-form.component.css']
})
export class ModelDrivenFormComponent implements OnInit {

  showusername: string;
  formdata: FormGroup;

  constructor() { }

  ngOnInit() {
    this.createForm();

  }

  createForm() {
    this.formdata = new FormGroup({
      username: new FormControl("t3h.edu.vn",
        Validators.compose([
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(20)
        ])
    ),
      pwd: new FormControl("abcd1234",[Validators.required, Validators.minLength(3)])
    });
  }
  
  get username() {
    return this.formdata.get('username');
  }
  
  get pwd() {
    return this.formdata.get('pwd');
  }


  onClickSubmit(data: any) {
    this.showusername = data.username;
  }

}

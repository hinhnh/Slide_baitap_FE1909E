import { Injectable } from '@angular/core';

//@Injectable({
 // providedIn: 'root'
//}//)

@Injectable()
export class DemoService {
  courses: string[] =[]
  constructor() {
    this.courses = ["angualar","typescript",
    "php","nodejs","reactjs","vue.js"];

   }

  getCourses(): string[] {
    return this.courses;
  }
}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import {ReactiveFormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { TemplateDrivenFormComponent } from './template-driven-form/template-driven-form.component';
import { ModelDrivenFormComponent } from './model-driven-form/model-driven-form.component';
import { ShowErrorsComponent } from './validate/show-error.component';
import { DependecyInjectionComponent } from './dependecy-injection/dependecy-injection.component';
import { CourseComponent } from './course/course.component';
import {DemoService} from './services/demo.service';
import { DependencyInject2Component } from './dependency-inject2/dependency-inject2.component';
import { ManagerUserComponent } from './manager-user/manager-user.component'

// Import http module
import {HttpClientModule} from '@angular/common/http';
import { RxjsdemoComponent } from './rxjsdemo/rxjsdemo.component';

import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
import { InMemoryDataService }  from './in-memory-data.service';

@NgModule({
  declarations: [
    AppComponent,
    TemplateDrivenFormComponent,
    ModelDrivenFormComponent,
    ShowErrorsComponent,
    DependecyInjectionComponent,
    CourseComponent,
    DependencyInject2Component,
    ManagerUserComponent,
    RxjsdemoComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [DemoService],
  bootstrap: [AppComponent]
})
export class AppModule { }

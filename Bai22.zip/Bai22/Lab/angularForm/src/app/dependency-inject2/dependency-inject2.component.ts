import { Component, OnInit } from '@angular/core';
import {DemoService} from './../Services/demo.service'
@Component({
  selector: 'app-dependency-inject2',
  templateUrl: './dependency-inject2.component.html',
  styleUrls: ['./dependency-inject2.component.css'],
  providers:[DemoService]
})
export class DependencyInject2Component implements OnInit {
  listCourses2: string [];
  constructor( private demoSr2: DemoService) { }

  ngOnInit() {
    this.listCourses2 =  this.demoSr2.getCourses();
  }

}

import { Component } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demo-router';
   
  constructor( private router: Router) { }
  gotoNavigate() {
    
    this.router.navigate(['navigate-page']).then( (e) => {
      if (e) {
        console.log("Navigation is successful!");
      } else {
        console.log("Navigation has failed!");
      }
    });


  }

  gotoNavigateUrl() {
      this.router.navigateByUrl('/navigate-url').then( e =>{
        if (e) {
          console.log("Navigation is successful!");
        } else {
          console.log("Navigation has failed!");
        }

      });
     


 }


}

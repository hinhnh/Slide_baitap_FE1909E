import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calculate-sum',
  templateUrl: './calculate-sum.component.html',
  styleUrls: ['./calculate-sum.component.scss']
})
export class CalculateSumComponent implements OnInit {

  constructor() { }
   public numberA: number =0;
   public numberB: number;
   public sumAB: number;
  ngOnInit() {
  }

  public calculateSum():void {
    this.sumAB = this.numberA + this.numberB;
  } 
}

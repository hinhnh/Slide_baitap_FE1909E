import { Component, Input,OnInit,EventEmitter } from '@angular/core';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'app-calcultator',
  templateUrl: './calcultator.component.html',
  styleUrls: ['./calcultator.component.scss']
})
export class CalcultatorComponent implements OnInit {

  numberA: number ;
  numberB: number ;
  sumAB: number;
  tong: number;
  constructor() { }

  ngOnInit() {
   }
  public sum(){
    this.sumAB = Number(this.numberA) * Number(this.numberB);     

  }
  onSubmit() {


  }
}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CalcultatorComponent } from './calcultator.component';

describe('CalcultatorComponent', () => {
  let component: CalcultatorComponent;
  let fixture: ComponentFixture<CalcultatorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CalcultatorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CalcultatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component } from '@angular/core';
import { CalcultatorComponent } from './calcultator/calcultator.component';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'starter';

  message:string ="Hello!"
}

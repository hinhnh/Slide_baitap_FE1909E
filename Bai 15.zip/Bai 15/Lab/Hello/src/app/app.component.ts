import { Component } from '@angular/core';
import  {NgForm} from '@angular/forms'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Hello';
  numberA: number;
  numberB: number;
  result: number;

  onSubmit() {
    this.result =  Number(this.numberA) + Number(this.numberB);
    //console.log(f.value);  // { first: '', last: '' }
    //console.log(f.valid);// false
  }

  minus ():void {
    this.result =  Number(this.numberA) - Number(this.numberB);
   }

   multiplication():void {
   this.result =  Number(this.numberA) * Number(this.numberB);
  }

  division():void {
    this.result =  Number(this.numberA) / Number(this.numberB);
   }

}

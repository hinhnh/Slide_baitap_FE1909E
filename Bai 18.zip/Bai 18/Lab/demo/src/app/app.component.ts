import { Component, ViewChild, AfterViewInit, ElementRef } from '@angular/core';
import {ChildrenComponent} from './children/children.component';
import { ChildComponent } from './child/child.component';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements AfterViewInit {
  title = 'starterComponent';
  listInput: any[] = ["ádsd","sfsfsf"];
  inputMessage1: string ="Data truyền vào cho component con!"; 
 
   @ViewChild(ChildrenComponent, {static: false}) child : ChildrenComponent;
   @ViewChild('myName',{static: false}) myName1: ElementRef;
 
   messageFromChild: string;
   messageFromOutPut: string;

   constructor() {
   }
   
  ngAfterViewInit(){
    // nhận message từ component con 
    this.messageFromChild = this.child.message;
    if( this.myName1.nativeElement != undefined)
       this.myName1.nativeElement.value = "Data input from control html33!";
}
  
receiveMessage($event) {
      this.messageFromOutPut = $event;
}


}

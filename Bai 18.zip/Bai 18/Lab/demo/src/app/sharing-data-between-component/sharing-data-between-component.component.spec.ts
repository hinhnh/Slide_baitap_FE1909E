import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SharingDataBetweenComponentComponent } from './sharing-data-between-component.component';

describe('SharingDataBetweenComponentComponent', () => {
  let component: SharingDataBetweenComponentComponent;
  let fixture: ComponentFixture<SharingDataBetweenComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SharingDataBetweenComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SharingDataBetweenComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

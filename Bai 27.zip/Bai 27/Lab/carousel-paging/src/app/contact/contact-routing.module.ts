import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { ContactListComponent } from '../contact/contact-list/contact-list.component';
import { ContactDetailComponent } from '../contact/contact-detail/contact-detail.component';


const routes: Routes = [
  {
    // khi không xác định trang con thì chuyển đến trang chỉ định
    path: '', redirectTo:'/contacts/contact-list', pathMatch: 'full'        
  },
  {
  path: 'contact-list',
  component: ContactListComponent
  },
  {
    path: 'contact-detail/:id',
    component: ContactDetailComponent
    },
    
];


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class ContactRoutingModule { }

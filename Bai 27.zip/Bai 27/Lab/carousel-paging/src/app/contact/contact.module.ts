import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContactListComponent } from '../contact/contact-list/contact-list.component';
import { ContactDetailComponent } from '../contact/contact-detail/contact-detail.component';
import { ContactRoutingModule } from './contact-routing.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations:[ContactListComponent,ContactDetailComponent],
  imports: [
    CommonModule,
    ContactRoutingModule,
    NgbModule
  ],  
  exports: [ContactListComponent]
  
})
export class ContactModule { }

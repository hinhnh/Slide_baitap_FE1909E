import { Component, OnInit } from '@angular/core';
import { ContactService } from '../contact.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-contact-list',
  templateUrl: './contact-list.component.html',
  styleUrls: ['./contact-list.component.css'] 

})
export class ContactListComponent implements OnInit {

  contacts: any[] = [];
  page = 1;
  pageSize = 2;

  constructor(private contactService: ContactService,
             private router: Router       
             ) {           

             }

  ngOnInit() {
    this.contactService.getContacts().subscribe((data : any[])=>{
              this.contacts = data;
    })
  }

  
  gotoDetailUser(id:number){
     
    this.router.navigate(['contacts/contact-detail', id]);
    

  }

}

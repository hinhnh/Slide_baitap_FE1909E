import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';  
import { BackendService } from './service/backend.service';
import {LoginModule} from './login/login.module';
import {ContactModule} from './contact/contact.module';


//import { ContactListComponent } from './contact/contact-list/contact-list.component';
//import { ContactDetailComponent } from './contact/contact-detail/contact-detail.component';

import {HttpClientModule} from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { NavigateComponent } from './navigate/navigate.component';
import { NavigateUrlComponent } from './navigate-url/navigate-url.component';
// import ng-bootrap Module
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MymodalComponent } from './mymodalcomponent/mymodalcomponent.component';
import { CarouselComponent } from './carousel/carousel.component';

@NgModule({
  declarations: [
    AppComponent,    
    HomeComponent,
    NavigateComponent,
    NavigateUrlComponent,
    MymodalComponent,
    CarouselComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    InMemoryWebApiModule.forRoot(BackendService),
    AppRoutingModule,
    HttpClientModule,
    NgbModule     
  ],
  entryComponents:[
    MymodalComponent
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

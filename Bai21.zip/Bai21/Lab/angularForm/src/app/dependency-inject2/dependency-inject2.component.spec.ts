import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DependencyInject2Component } from './dependency-inject2.component';

describe('DependencyInject2Component', () => {
  let component: DependencyInject2Component;
  let fixture: ComponentFixture<DependencyInject2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DependencyInject2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DependencyInject2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

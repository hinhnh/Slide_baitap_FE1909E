import { Component, OnInit } from '@angular/core';
import {DemoService} from './../services/demo.service'
@Component({
  selector: 'app-dependecy-injection',
  templateUrl: './dependecy-injection.component.html',
  styleUrls: ['./dependecy-injection.component.css'],
  providers:[DemoService]
})
export class DependecyInjectionComponent implements OnInit {
   listCourses: string [];
  constructor(  private demoSv: DemoService) { }

  ngOnInit() {
     // Cach goi class voi new object chua dung DI
     //let computer : Computer = new Computer();
     let computer : Computer = new Computer(new CPU());
     let computer1 : Computer = new Computer(new OCCPU());
    computer.cpu.start();
    computer1.cpu.start();
     // Service da dung DI
     this.listCourses =  this.demoSv.getCourses();
    
  }

}



class CPU {
  constructor() {}
  start() {
    console.log('CPU speed 3.2GHz');
    alert('CPU speed 3.2GHz');
  }
}

class OCCPU extends CPU {
  constructor() {
    super();
  }
  start() {
    console.log('CPU speed 3.7GHz');
    alert('CPU speed 3.7GHz');
  }
}


class Computer {
  public cpu: CPU;
  //  constructor() {
  //    this.cpu = new CPU();// nếu không new object CPU trong constructor chuong trình lỗi
  //  }
    
   constructor(cpu: CPU) {
     this.cpu = cpu;
   }
}

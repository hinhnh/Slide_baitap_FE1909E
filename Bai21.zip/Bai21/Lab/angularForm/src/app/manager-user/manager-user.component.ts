import { Component, OnInit } from '@angular/core';
import {UserService} from './user.service';
//import { Observable } from 'rxjs';
import {Observable} from 'rxjs';
@Component({
  selector: 'app-manager-user',
  templateUrl: './manager-user.component.html',
  styleUrls: ['./manager-user.component.css']
})
export class ManagerUserComponent implements OnInit {
   listUsers: any[];
  constructor(private userService: UserService) {  }

  ngOnInit() {
             
    this.userService.getJSON().subscribe(
      (res: any) => {
           this.listUsers = res;
           console.log(this.listUsers);
         }, 
      err => {
         console.log(err);
            }
      );


    /*
    this.userService.getUsers()
      .then( result => {
        console.log('ALL Data: ', result);
        this.listUsers = result;
      })
      .catch( error => {
        console.log('Error Getting Data: ', error);
      });
     */
   
  }

}
//https://www.metaltoad.com/blog/angular-5-making-api-calls-httpclient-service//
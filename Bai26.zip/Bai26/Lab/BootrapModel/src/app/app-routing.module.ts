import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
//import { ContactListComponent } from './contact/contact-list/contact-list.component';
//import { ContactDetailComponent } from './contact/contact-detail/contact-detail.component';
import { HomeComponent } from './home/home.component';
import { NavigateComponent } from './navigate/navigate.component';
import { NavigateUrlComponent } from './navigate-url/navigate-url.component';
//import { LoginComponent } from './login/login.component';
import { AuthGuardService } from './service/auth-guard.service'; 

const routes: Routes = [
    
  // Lazy async modules
  {
    path: 'login',
    loadChildren: './login/login.module#LoginModule',
    data: {  
      title: 'Login'  
    }  
 },  
  {path: 'home' ,
   component: HomeComponent,
   canActivate: [AuthGuardService],
   data: {
     title:"Home page"
   }  
  },
  { path:'contacts', loadChildren: './contact/contact.module#ContactModule',
   canActivate: [AuthGuardService]
},
  //{path: 'home' , component: HomeComponent,outlet:'home1'},
  //{path: 'contacts' , component: ContactListComponent},
 // {path: 'contact/:id' , component: ContactDetailComponent},
  {path: 'navigate-page' , component: NavigateComponent},
  {path: 'navigate-url' , component: NavigateUrlComponent},
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

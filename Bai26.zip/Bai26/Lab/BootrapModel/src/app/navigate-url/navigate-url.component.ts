import { Component, OnInit } from '@angular/core';
import {NgbModal, NgbModalOptions} from '@ng-bootstrap/ng-bootstrap';

import{MymodalComponent} from '../mymodalcomponent/mymodalcomponent.component';

@Component({
  selector: 'app-navigate-url',
  templateUrl: './navigate-url.component.html',
  styleUrls: ['./navigate-url.component.css']
})
export class NavigateUrlComponent implements OnInit {
  title = 'ng-bootstrap-modal-demo';
  closeResult: string;
  modalOptions:NgbModalOptions;
  MESSAGE_DATA: string;

  constructor(  private modalService: NgbModal) { 
   

  }
  ngOnInit():void {

  }

  open() {
    const modalRef = this.modalService.open(MymodalComponent);
    modalRef.componentInstance.my_modal_title = 'I your title is passed from parent';
    modalRef.componentInstance.my_modal_content = 'I am your content';
  }

 

}

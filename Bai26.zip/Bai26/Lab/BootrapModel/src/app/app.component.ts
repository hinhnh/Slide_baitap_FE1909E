import { Component } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import{MymodalComponent} from './mymodalcomponent/mymodalcomponent.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demo-router';
   
  constructor( private router: Router, private modalService: NgbModal) { }

  open() {
    const modalRef = this.modalService.open(MymodalComponent);
    modalRef.componentInstance.my_modal_title = 'I your title is passed from parent';
    modalRef.componentInstance.my_modal_content = 'I am your content';
  }


  gotoNavigate() {
    
    this.router.navigate(['navigate-page']).then( (e) => {
      if (e) {
        console.log("Navigation is successful!");
      } else {
        console.log("Navigation has failed!");
      }
    });


  }

  gotoNavigateUrl() {
      this.router.navigateByUrl('/navigate-url').then( e =>{
        if (e) {
          console.log("Navigation is successful!");
        } else {
          console.log("Navigation has failed!");
        }

      });
     


 }


}

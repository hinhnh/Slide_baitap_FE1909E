let fullName: string = `Bob Bobbington`;
let fullName1: string = `Bob Bobbington1`;
let age: number = 37;
let sentence: string = `Hello, my name is ${ fullName +  fullName1 }.
  I'll be ${ age + 1 } years old next month.`
  
console.log('=== Kieu du lieu string======:');
console.log(sentence);

console.log('=== Kieu du lieu array======:');
let list1: number[] = [1, 2, 3];
let list2: Array < number > = [1, 2, 3];
console.log(list1);
let stringArray_1: Array < string > =['Welcome', 'to', 'Vietpro']; 
console.log(stringArray_1);

// Declare a tuple type
let x: [string, number];
// Initialize it
x = ["hello", 10]; // OK
// Initialize it incorrectly
//x = [10, "hello"]; // Error
console.log(x);

console.log("==Kieu enum====");

enum Hello {
    Xinchao= 10,
    Hi,
    Bonjour
};
let vietnam: Hello = Hello.Xinchao;
console.log(vietnam);
    vietnam = Hello.Bonjour;
    console.log(vietnam);

    console.log("+++Kieu void====");
    function showAlert(): void {
        console.log("Welcome to Viet Nam");
        //alert('Hi';)
    }
    showAlert();
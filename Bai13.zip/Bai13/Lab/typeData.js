var fullName = "Bob Bobbington";
var fullName1 = "Bob Bobbington1";
var age = 37;
var sentence = "Hello, my name is " + (fullName + fullName1) + ".\n  I'll be " + (age + 1) + " years old next month.";
console.log('=== Kieu du lieu string======:');
console.log(sentence);
console.log('=== Kieu du lieu array======:');
var list1 = [1, 2, 3];
var list2 = [1, 2, 3];
console.log(list1);
var stringArray_1 = ['Welcome', 'to', 'Vietpro'];
console.log(stringArray_1);
// Declare a tuple type
var x;
// Initialize it
x = ["hello", 10]; // OK
// Initialize it incorrectly
//x = [10, "hello"]; // Error
console.log(x);
console.log("==Kieu enum====");
var Hello;
(function (Hello) {
    Hello[Hello["Xinchao"] = 10] = "Xinchao";
    Hello[Hello["Hi"] = 11] = "Hi";
    Hello[Hello["Bonjour"] = 12] = "Bonjour";
})(Hello || (Hello = {}));
;
var vietnam = Hello.Xinchao;
console.log(vietnam);
vietnam = Hello.Bonjour;
console.log(vietnam);
console.log("+++Kieu void====");
function showAlert() {
    console.log("Welcome to Viet Nam");
    //alert('Hi';)
}
showAlert();

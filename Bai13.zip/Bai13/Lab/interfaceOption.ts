interface SquareConfig {
    color?: string;
    width?: number;
}
;
function createSquare(config: SquareConfig): {color: string; area: number} {
    let newSquare = {color: "white", area: 100};
    if (config.color) {
        newSquare.color = config.color;
    }
    if (config.width) {
        newSquare.area = config.width * config.width;
    }
    return newSquare;
}
;
let mySquare = createSquare({color: "black", width:12});


interface CircleConfig {
    color?: string;
    radius?: number;
    diameter?:number;
}
function createCircle(config: CircleConfig): {color: string; radius: number; diameter:number} {
    let newCircle = {color: "white", radius: 100, diameter: 1000};
    if (config.color) {
        newCircle.color = config.color;
    }
    if (config.diameter) {
        newCircle.diameter = 2 * config.radius;
    }
    return newCircle;
}

let circle = createCircle({color: "black", radius: 150,diameter: 2 });
//let circle = createCircle({color: "black", radius: 150});// khong truyen thuoc tinh diameter
console.log("diameter: " + circle.diameter);




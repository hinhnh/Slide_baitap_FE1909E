interface Shape 
{
 color: string;
 }
 interface PenStroke
 {
 penWidth: number; 
}

 interface Circle extends Shape, PenStroke
 {
 sideRadius: number;
 }
 let circle: Circle  =  <Circle>{};
 circle .color = "blue";
 circle . sideRadius = 10;
 circle .penWidth = 5.0; 
 console.log('circle .color22: '+ circle.color);


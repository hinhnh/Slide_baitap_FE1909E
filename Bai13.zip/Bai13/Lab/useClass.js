var Car = /** @class */ (function () {
    //constructor 
    function Car(engine) {
        this._engine = engine;
    }
    //function 
    Car.prototype.disp = function () {
        console.log("Function displays Engine is  :   " + this._engine);
    };
    return Car;
}());
//create an object 
var obj = new Car("XYZ");
//access the field 
console.log("Reading attribute value Engine as :  " + obj._engine);
//access the function
obj.disp();
//==========================================================
var Human = /** @class */ (function () {
    //constructor 
    function Human(hair) {
        this.hair = hair;
    }
    Human.prototype.run = function (tocdo) {
        console.log('Hành động chạy:' + tocdo);
        this.sleep();
    };
    Human.prototype.sleep = function () {
        console.log('Hành động ngủ!');
    };
    return Human;
}());
var objHuman = new Human('black');
console.log(objHuman.run("fast"));
console.log('****************');

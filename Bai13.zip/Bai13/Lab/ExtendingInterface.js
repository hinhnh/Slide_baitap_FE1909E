var circle = {};
circle.color = "blue";
circle.sideRadius = 10;
circle.penWidth = 5.0;
console.log('circle .color22: ' + circle.color);

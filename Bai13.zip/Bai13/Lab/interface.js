function printLabel(labelObj) {
    console.log("Label1: " + labelObj.label + " - Size: " + labelObj.size);
}
var _object = { size: 10, label: "Size 10" };
printLabel(_object);

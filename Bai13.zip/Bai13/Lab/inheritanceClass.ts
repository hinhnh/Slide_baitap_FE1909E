class Shape { 
   Area:number 
   
   constructor(a:number) { 
      this.Area = a 
   } 
} 

class Circle extends Shape { 
   disp():void { 
      console.log("Area of the circle:  "+this.Area) 
   } 
}
  
var obj = new Circle(446); 
obj.disp()

console.log('Kế thừa nhiều mức!!')
class Root{
 treeName: string;
}
class Child extends Root{
}
class Leaf extends Child {
    disp() {
       console.log("Lá của cây:"+ this.treeName);
    }
}

let objLeaf = new Leaf();
objLeaf.treeName = "Cây Phượng!"
console.log('Tên cây:'+ objLeaf.treeName);
objLeaf.disp();

/// Phạm vi truy cập các thuọc tính trong class
console.log("Tính đóng gói trong Class: Encapsulation");
class Encapsulate { 
          
   strHi:string = "hello" // default public
   private str2:string = "world" ;
   protected str3: string ="Welcome to TypeScript";
     
}


class ChildInheritance extends Encapsulate{}
 
let obj1 = new Encapsulate() 
console.log(obj1.strHi) ;    //accessible 
//console.log(obj.str2)   //compilation Error as str2 is private
//console.log(obj1.str3)   //compilation Error as str2 is protected
//let obj2 = new ChildInheritance();

console.log("Tính đóng gói trong Class: Encapsulation- Protected modifier  ");
class Person {
   protected name: string;
   constructor(name: string) { this.name = name; }
}


//========== Protected modifier 
class Employee extends Person {
   private department: string;

   constructor(name: string, department: string) {
       super(name);// khi kế thừa constructor lớp cha
       this.department = department;
   }
   
   //this.name thuộc lớp cha Person chỉ có thể gọi trong lóp con kế thừa. Nếu gọi ngoài lớp con sẽ bị lỗi
   public getElevatorPitch() {
       return `Hello, my name is ${this.name} and I work in ${this.department}.`;
   }
}

let howard = new Employee("Howard", "Sales");
console.log(howard.getElevatorPitch());
//console.log(howard.name); // error
interface ILabelValue {
    label: string;
    size: number;
}

function printLabel(labelObj: ILabelValue) {
        console.log("Label1: " + labelObj.label + " - Size: " + labelObj.size); 
}

let _object: ILabelValue = {size: 10, label: "Size 10"};
printLabel(_object);

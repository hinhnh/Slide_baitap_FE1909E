var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Shape = /** @class */ (function () {
    function Shape(a) {
        this.Area = a;
    }
    return Shape;
}());
var Circle = /** @class */ (function (_super) {
    __extends(Circle, _super);
    function Circle() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Circle.prototype.disp = function () {
        console.log("Area of the circle:  " + this.Area);
    };
    return Circle;
}(Shape));
var obj = new Circle(446);
obj.disp();
console.log('Kế thừa nhiều mức!!');
var Root = /** @class */ (function () {
    function Root() {
    }
    return Root;
}());
var Child = /** @class */ (function (_super) {
    __extends(Child, _super);
    function Child() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return Child;
}(Root));
var Leaf = /** @class */ (function (_super) {
    __extends(Leaf, _super);
    function Leaf() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Leaf.prototype.disp = function () {
        console.log("Lá của cây:" + this.treeName);
    };
    return Leaf;
}(Child));
var objLeaf = new Leaf();
objLeaf.treeName = "Cây Phượng!";
console.log('Tên cây:' + objLeaf.treeName);
objLeaf.disp();
/// Phạm vi truy cập các thuọc tính trong class
console.log("Tính đóng gói trong Class: Encapsulation");
var Encapsulate = /** @class */ (function () {
    function Encapsulate() {
        this.strHi = "hello"; // default public
        this.str2 = "world";
        this.str3 = "Welcome to TypeScript";
    }
    return Encapsulate;
}());
var ChildInheritance = /** @class */ (function (_super) {
    __extends(ChildInheritance, _super);
    function ChildInheritance() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return ChildInheritance;
}(Encapsulate));
var obj1 = new Encapsulate();
console.log(obj1.strHi); //accessible 
console.log(obj.str2); //compilation Error as str2 is private
console.log(obj1.str3); //compilation Error as str2 is protected
//let obj2 = new ChildInheritance();
console.log("Tính đóng gói trong Class: Encapsulation- Protected modifier  ");
var Person = /** @class */ (function () {
    function Person(name) {
        this.name = name;
    }
    return Person;
}());
//========== Protected modifier 
var Employee = /** @class */ (function (_super) {
    __extends(Employee, _super);
    function Employee(name, department) {
        var _this = _super.call(this, name) || this;
        _this.department = department;
        return _this;
    }
    //this.name thuộc lớp cha Person chỉ có thể gọi trong lóp con kế thừa. Nếu gọi ngoài lớp con sẽ bị lỗi
    Employee.prototype.getElevatorPitch = function () {
        return "Hello, my name is " + this.name + " and I work in " + this.department + ".";
    };
    return Employee;
}(Person));
var howard = new Employee("Howard", "Sales");
console.log(howard.getElevatorPitch());
//console.log(howard.name); // error

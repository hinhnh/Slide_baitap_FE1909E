import { Directive ,ElementRef } from '@angular/core';
import { element } from 'protractor';
@Directive({
  selector: 'appChangeText'
})
export class ChangeTextDirective {

  constructor(Element: ElementRef) { 

    console.log(Element);
    Element.nativeElement.innerText = "T3H- học lập trình Angular";

  }

}

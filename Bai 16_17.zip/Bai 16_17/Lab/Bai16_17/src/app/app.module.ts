import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NewCmpComponent } from './new-cmp/new-cmp.component';
import { CmpAComponent } from './cmp-a/cmp-a.component';
import { ChangeTextDirective } from './change-text.directive';
import { UseDirectiveComponent } from './use-directive/use-directive.component';

@NgModule({
  declarations: [
    AppComponent,
    NewCmpComponent,
    CmpAComponent,
    ChangeTextDirective,
    UseDirectiveComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

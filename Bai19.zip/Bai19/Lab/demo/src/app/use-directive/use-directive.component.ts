import { Component, OnInit } from '@angular/core';
import { SSL_OP_NO_TLSv1_1 } from 'constants';

@Component({
  selector: 'app-use-directive',
  templateUrl: './use-directive.component.html',
  styleUrls: ['./use-directive.component.css']
})
export class UseDirectiveComponent implements OnInit {
  arrayObject = ["Học TypeScript", "Học Angular 4", "Học HTML5"];
  superhero :string ="Groot";
  Cars: any[] = [
    {
      "name": "BMW",
      "age": 12,
      "color": 'blue'
    },
    {
      "name": "Ford",
      "age": 15,
      "color": 'yellow'
    },
    {
      "name": "Suzuki",
      "age": 18,
      "color": 'silver'
    },
    {
      "name": "MG Hector",
      "age": 14,
      "color": 'red'
    },
    {
      "name": "Jaguar",
      "age": 8,
      "color": 'green'
    }
  ];

  applygreenstyle: boolean = true;  
  borderStyle = '1px solid black';  
  appStyleGreen = {  
        'color': 'green',  
        'font-weight': 'bold',  
        'font-size': '45px',  
        'borderBottom': this.borderStyle,  
        'padding': '1rem'  
    };  
    appStyleBlue = {  
        'color': 'blue',  
        'font-weight': 'bold',  
        'font-size': '45px',  
        'borderBottom': this.borderStyle,  
        'padding': '1rem'  
    };  
    ChangeColor(): void {  
        this.applygreenstyle = !this.applygreenstyle;  
    }  


    stateFlag: boolean = false;

    toggleState() {
        this.stateFlag = !this.stateFlag;
    }

    submit() {
        console.log('Button submitted');
    }

    calculateClasses() {
        return {
            'btn': true,
            'btn-primary': true,
            'btn-extra-class': this.stateFlag
        };
    }
  
    selectedTab: string = 'tab1';

    selectTab(tabName: string) {
       this.selectedTab = tabName;
    }

  constructor() { }

  ngOnInit() {
  }

}

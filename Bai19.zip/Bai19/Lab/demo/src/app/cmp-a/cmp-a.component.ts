import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cmp-a',
  template: `<h1> Template Inline!</h1>
             <p>{{title}} </p>
             <div>{{arrayObject[1]}} </div>             
             `,
  styleUrls: ['./cmp-a.component.css']
})
export class CmpAComponent implements OnInit {
   title: string = "Lập trình Angular";
   arrayObject = ["Học TypeScript", "Học Angular 4", "Học HTML5"];
  constructor() { }

  ngOnInit() {
  }

}

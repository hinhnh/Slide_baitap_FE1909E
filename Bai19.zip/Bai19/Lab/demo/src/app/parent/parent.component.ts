import { Component, OnInit } from '@angular/core';
import { DataService } from "../services/data.service";
import { ChildComponent } from '../child/child.component';
@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {
  message: string;
  constructor( private data: DataService) {

   }

  ngOnInit() {
    // hàm này nhân  data từ DataService truyền tới qua: this.messageSource.next(message)
    this.data.currentMessage.subscribe(message => this.message = message)
  }

  changeMessage(){
      //this.data.changeMessage('Hello from Parent!');
      this.data.changeMessage(this.message);
  }

}

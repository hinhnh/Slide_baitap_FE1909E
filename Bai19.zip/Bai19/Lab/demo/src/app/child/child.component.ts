import { Component, OnInit, Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
  @Output() outputMessage = new EventEmitter<string>();
  message: string;
  constructor() { }
  
  ngOnInit() {
  }

  sendMessage() {
    this.outputMessage.emit(this.message)

  }

}

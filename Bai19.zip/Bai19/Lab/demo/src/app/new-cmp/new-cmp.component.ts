import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-cmp',
  templateUrl: './new-cmp.component.html',
  styleUrls: ['./new-cmp.component.css']
})
export class NewCmpComponent implements OnInit {
  title: string ="-Lập trinh Front-end";
  // Khai báo mảng dữ liệu
  todo = ["Học TypeScript", "Học Angular 4", "Học HTML5"];
  superhero = 'Spiderman';   
  superhero1 = 'Thor';  
  
  Cars: any[] = [
    {
      "name": "BMW",
      "average": 12,
      "color": 'blue'
    },
    {
      "name": "Ford",
      "age": 15,
      "color": 'yellow'
    },
    {
      "name": "Suzuki",
      "age": 18,
      "color": 'silver'
    },
    {
      "name": "MG Hector",
      "age": 14,
      "color": 'red'
    },
    {
      "name": "Jaguar",
      "age": 8,
      "color": 'green'
    }
  ];
  

  applygreenstyle: boolean = true;  
  borderStyle = '1px solid black';  
  appStyleGreen = {  
        'color': 'green',  
        'font-weight': 'bold',  
        'font-size': '45px',  
        'borderBottom': this.borderStyle,  
        'padding': '1rem'  
    };  
    appStyleBlue = {  
        'color': 'blue',  
        'font-weight': 'bold',  
        'font-size': '45px',  
        'borderBottom': this.borderStyle,  
        'padding': '1rem'  
    };  
    ChangeColor(): void {  
        this.applygreenstyle = !this.applygreenstyle;  
    }  


  constructor() { }

  ngOnInit() {
  
  }

     stateFlag = false;

    toggleState() {
        this.stateFlag = !this.stateFlag;
    }

    submit() {
      this.stateFlag = !this.stateFlag;
    }

    calculateClasses() {
        return {
            'btn': true,
            'btn-primary': true,
            'btn-extra-class': this.stateFlag
        };
    }






}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sharing-data-between-component',
  templateUrl: './sharing-data-between-component.component.html',
  styleUrls: ['./sharing-data-between-component.component.css']
})
export class SharingDataBetweenComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

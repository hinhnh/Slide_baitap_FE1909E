import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NewCmpComponent } from './new-cmp/new-cmp.component';
import { CmpAComponent } from './cmp-a/cmp-a.component';
import { ChangeTextDirective } from './change-text.directive';
import { UseDirectiveComponent } from './use-directive/use-directive.component';
import { SharingDataBetweenComponentComponent } from './sharing-data-between-component/sharing-data-between-component.component';
import { ChildrenComponent } from './children/children.component';
import { ParentComponent } from './parent/parent.component';
import { SiblingComponent } from './sibling/sibling.component';
import { ChildComponent } from './child/child.component';
import { GameListComponent } from './game-list/game-list.component';
import { AngularPipeComponent } from './angular-pipe/angular-pipe.component';

// Chỉ ra đường dẫn của sqrt pipe
import { SqrtPipe } from './custom-pipe/pipe.sqrt';
import { SearchPipe } from './custom-pipe/pipe.search';
import { EventBindingComponent } from './event-binding/event-binding.component';

@NgModule({
  declarations: [
    AppComponent,
    NewCmpComponent,
    CmpAComponent,
    ChangeTextDirective,
    UseDirectiveComponent,
    SharingDataBetweenComponentComponent,
    ChildrenComponent,
    ParentComponent,
    SiblingComponent,
    ChildComponent,
    GameListComponent,
    AngularPipeComponent,
     // Import Class Pipe
     SqrtPipe,
     SearchPipe,
     EventBindingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

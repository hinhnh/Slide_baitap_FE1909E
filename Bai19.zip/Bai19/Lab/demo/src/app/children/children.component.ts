import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-children',
  templateUrl: './children.component.html',
  styleUrls: ['./children.component.css']
})
export class ChildrenComponent implements OnInit {
  @Input() inputMessage: string;
  @Input() list: any[];
  //inputMessage: string;
  message: string ="this message is sent from child component!";  
  constructor() { }

  ngOnInit() {
  }

}

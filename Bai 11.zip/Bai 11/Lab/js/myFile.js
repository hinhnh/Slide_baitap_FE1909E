//$(function () {
    //$("#start").html("Go!");
   // $("#start").html("Welcome to jQuery!");
    //$("#name").val("Welcome to jQuery!");
    //var phone = $("#phone").val();
   // alert(phone);
//});

$(document).ready(function() {
    $("#start").html("Welcome to jQuery!");
     $("#name").val("Welcome to jQuery!");
     var phone =  $("#phone").val();
     alert(phone);
    });
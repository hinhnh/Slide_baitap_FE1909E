import { Component, OnInit } from '@angular/core';
import { getMaxListeners } from 'cluster';

@Component({
  selector: 'app-template-driven-form',
  templateUrl: './template-driven-form.component.html',
  styleUrls: ['./template-driven-form.component.css']
})
export class TemplateDrivenFormComponent implements OnInit {
   userName :string = "t3h@getMaxListeners.com";
   passWord:string = "12345";
  constructor() { }

  ngOnInit() {
  }

  onClickSubmit1() {
    alert("Username bạn vừa nhập là :"+ this.userName);
 }

 onClickSubmit(data: any) {
  alert("Username bạn vừa nhập là : " + data.value.email);
}

}

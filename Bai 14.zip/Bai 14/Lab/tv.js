export function tong(a, b) {
    return a + b;
}
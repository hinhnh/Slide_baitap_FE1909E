"use strict";
exports.__esModule = true;
function tong(a, b) {
    return a + b;
}
exports["default"] = tong;
function hieu(a, b) { return a - b; }
exports.hieu = hieu;
;

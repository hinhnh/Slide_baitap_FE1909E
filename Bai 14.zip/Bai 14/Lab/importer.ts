import sayHi = require('./exporter.js');
sayHi();
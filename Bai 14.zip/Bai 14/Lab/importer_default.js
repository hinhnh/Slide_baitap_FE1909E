"use strict";
exports.__esModule = true;
// cách này cho phép ta chỉ import 
var exporter_default_1 = require("./exporter_default");
console.log('sum:' + exporter_default_1["default"](5, 3));
//import {default as mySum, hieu} from './exporter_default';
//console.log('Subtraction :'+ hieu(5,3));
// cách này cho phép ta import cả foo và bar
//import hieu, {tong} from './exporter_default.ts';
var myMath = require("./exporter_default");
console.log('Subtraction: ', myMath.hieu(5, 4));
  function foo() { return 'foo'; }

  function bar() { return 'bar'; }
  //export *  from './foobar';
  export { foo, bar };
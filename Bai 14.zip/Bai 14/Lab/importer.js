"use strict";
exports.__esModule = true;
var sayHi = require("./exporter");
sayHi();

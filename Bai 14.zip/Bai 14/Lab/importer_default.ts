// cách này cho phép ta chỉ import 
import tt from './exporter_default';
console.log('sum:'+ tt(5,3));

//import {default as mySum, hieu} from './exporter_default';

//console.log('Subtraction :'+ hieu(5,3));
// cách này cho phép ta import cả foo và bar
//import hieu, {tong} from './exporter_default.ts';
import * as myMath from './exporter_default'
console.log('Subtraction: ', myMath.hieu(5,4));
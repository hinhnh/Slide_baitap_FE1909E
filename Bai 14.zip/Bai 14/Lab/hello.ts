//import sayHello = require('./say_hello.js');
import {sayHello as say} from './say_hello';
say("Peter");

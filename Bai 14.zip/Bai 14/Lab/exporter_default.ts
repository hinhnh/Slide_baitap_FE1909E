export default function tong(a: number, b: number): number {
    return  a+b;
}

export function hieu(a:number,b:number):number { return a-b; };
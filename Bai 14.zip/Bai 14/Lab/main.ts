//import { foo, bar } from './foobar';
//import  *  as tv from './foobar';
//tv.foo();
//tv.bar();

console.log("Import tat ca  class trong Module!");
import * as lib from './foobar.js';
console.log(lib.foo());
console.log(lib.bar());

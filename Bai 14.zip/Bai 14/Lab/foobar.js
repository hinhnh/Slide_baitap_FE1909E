"use strict";
exports.__esModule = true;
function foo() { return 'foo'; }
exports.foo = foo;
function bar() { return 'bar'; }
exports.bar = bar;

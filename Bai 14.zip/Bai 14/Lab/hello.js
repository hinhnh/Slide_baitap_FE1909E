"use strict";
exports.__esModule = true;
//import sayHello = require('./say_hello.js');
var say_hello_1 = require("./say_hello");
say_hello_1.sayHello("Peter");

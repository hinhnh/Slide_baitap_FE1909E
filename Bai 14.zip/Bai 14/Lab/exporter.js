"use strict";
var sayHi = function () {
    console.log("Hello!");
};
module.exports = sayHi;

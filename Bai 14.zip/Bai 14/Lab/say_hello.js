"use strict";
// let sayHello = function (name) {
//     console.log("Xin chào! Tên tôi là " + name);
// }
// export = sayHello;
exports.__esModule = true;
var sayHello = function (name) {
    console.log("Xin chào! Tên tôi là " + name);
};
exports.sayHello = sayHello;

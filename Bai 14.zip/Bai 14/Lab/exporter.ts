var sayHi = function(): void {
    console.log("Hello!");
}

export = sayHi;
// let sayHello = function (name) {
//     console.log("Xin chào! Tên tôi là " + name);
// }
// export = sayHello;

let sayHello = function (name) {
    console.log("Xin chào! Tên tôi là " + name);
}

export { sayHello };
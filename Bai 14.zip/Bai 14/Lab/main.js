"use strict";
exports.__esModule = true;
var foobar_1 = require("./foobar");
foobar_1.foo();
foobar_1.bar();
console.log("Import tat ca  class trong Module!");
var lib = require("./foobar");
console.log(lib.foo());
console.log(lib.bar());

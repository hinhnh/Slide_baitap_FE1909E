﻿//export function addTextToBody(text) {
//    const div = document.createElement('div');
//    div.textContent = text;
//    document.body.appendChild(div);
   
//}

export function showSum() {
    document.getElementById("numA").value = 6;
    var b = document.getElementById("numB").value = 3;  
    document.getElementById("txtSum").value = tong(6, 3);
}

 function tong(a, b) {    
    return a + b;
}
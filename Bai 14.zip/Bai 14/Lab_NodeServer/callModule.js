var sayHello = require('./DeclareModule.js');
sayHello("Peter");
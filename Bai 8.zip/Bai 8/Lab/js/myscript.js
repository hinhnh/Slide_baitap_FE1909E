document.getElementById("demo1").innerHTML = "Tài liệu học Html5";
document.getElementById("demo2").innerHTML = "Tài liệu học Css";
document.getElementById("demo3").innerHTML = "Tài liệu học JavaScript";